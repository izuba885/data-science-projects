# Calgary Crime Analysis

This project analyzes Calgary crime data using Python.
It loads, cleans, analyzes, and visualizes crime statistics
from Calgary communities between 2018 and 2023, and compares
it against updated 2024 data.

	Key Features:

- Data cleaning and validation
- Crime analysis by year, type, and location
- Identification of dangerous and safe communities
- Community comparison by crime
- Rising crime trend detection
- Visualization of crime trends and comparisons

# Project Structure

Project

/data/
Community_Crime_Statistics_20240102.csv
Community-Crime-2024-2025.csv
Cleaned_Crime_Data.csv

/src/
DataCleaning.py
AnalyzeCalgaryCrime.py
DataVisualization.py
Main.py

/plots/
crimes_per_year.png
top_communities.png
original_vs_updated_data.png
crime_distribution_by_type.png

README.txt

# Instructions

1. Install Pandas, NumPy, and Matplotlib

2. Place the CSV files inside the /data/ folder

3. Inside the /src/ folder, run Main.py