import pandas as pd

class AnalyzeCalgaryCrime: 
    def __init__(self, df):
        """Initialize the class with the crime data from the CSV file.
        Parameters:
        data (str): The file path to the CSV file containing the crime data.
        """
        self.df = df
        self.crime_totals = df.groupby('Community Name')['Crime Count'].sum().reset_index()

    def basic_stats(self):
        """
        Returns a dictionary of statistics for the Crime Count column.
        """
        return {
            "Mean": round(self.df['Crime Count'].mean(), 2),
            "Median": round(self.df['Crime Count'].median(), 2),
            "Std": round(self.df['Crime Count'].std(), 2),
            "Min": self.df['Crime Count'].min(),
            "Max": self.df['Crime Count'].max(),
            "Total": self.df['Crime Count'].sum()
        }

    def crime_by_year(self):
        """
        Calculate the total crime count for each year.
        Returns:
            DataFrame with years and their corresponding total crime counts.
        """
        return self.df.groupby('Year')['Crime Count'].sum().reset_index()

    def crime_by_type(self):
        """
        Calculate the total crime count for each type of crime.
        Returns:
            Series with crime categories and their corresponding total crime counts, sorted in descending order.
        """
        return self.df.groupby('Category')['Crime Count'].sum().sort_values(ascending=False)

    def crime_by_location(self):
        """
        Calculate the total crime count for each community.
        Returns:
            Series with community names and their corresponding total crime counts, sorted in descending order.
        """
        return self.df.groupby('Community Name')['Crime Count'].sum().sort_values(ascending=False)

    def get_dangerous_areas(self, threshold):
        """
        Identify the most dangerous areas by total crime count.
        Parameters:
            threshold (int): Number of top communities to return.
        Returns:
            DataFrame with community names and their corresponding total crime counts, sorted in descending order, limited to the specified threshold.
        """
        return self.crime_totals.sort_values(by='Crime Count', ascending=False).head(threshold)

    def get_safest_communities(self, threshold):
        """
        Identify the safest residential communities by total crime count.
        Parameters:
            threshold (int): Number of bottom communities to return.
        Returns:
            DataFrame with community names and their corresponding total crime counts, sorted in ascending order, limited to the specified threshold.
        """
        residential = self.df[self.df['Resident Count'] > 0]
        safest = residential.groupby('Community Name')['Crime Count'].sum().reset_index()
        return safest.sort_values(by='Crime Count', ascending=True).head(threshold)

    def common_crimes_by_community(self, community):
        """
        Get the most common crime type in a specified community.
        Parameters:
            community (str): The name of the community to analyze.
        Returns:
            The crime category with the highest total crime count in the specified community.
        """
        group_comm = self.df[self.df['Community Name'] == community].groupby('Category')['Crime Count'].sum().reset_index()
        answers = group_comm.groupby(level=0)['Crime Count'].sum().sort_values(ascending=False).idxmax()
        return answers

    def crime_and_population_correlation(self):
        """
        Calculate the crime rate relative to population for each community.
        Returns:
            DataFrame with community names, total crime counts, average resident counts,
            and the calculated crime-to-population ratio, sorted by the ratio in descending order.
        """
        residential = self.df[self.df['Resident Count'] > 100]
        crime = residential.groupby('Community Name')['Crime Count'].sum().reset_index()
        population = residential.groupby('Community Name')['Resident Count'].mean().reset_index()
        merged = crime.merge(population, on='Community Name')
        merged['Crime Rate'] = merged['Crime Count'] / merged['Resident Count']
        return (merged[['Community Name', 'Crime Count', 'Resident Count', 'Crime Rate']]
                .sort_values('Crime Rate', ascending=False))

    def compare_communities(self, community1, community2):
        """
        Compare crime counts between two communities.
        Parameters:
            community1 (str): The name of the first community to compare.
            community2 (str): The name of the second community to compare.
        Returns:
            A dictionary containing the total crime counts for both communities and the difference.
        """
        community1_df = self.df[self.df['Community Name'] == community1]
        community2_df = self.df[self.df['Community Name'] == community2]

        if community1_df.empty or community2_df.empty:
            return None

        total1 = community1_df['Crime Count'].sum()
        total2 = community2_df['Crime Count'].sum()

        return {
            "Community 1": community1,
            "Community 2": community2,
            "Total Crimes 1": total1,
            "Total Crimes 2": total2,
            "Difference": abs(total1 - total2),
            "Safer Community": community2 if total1 > total2 else community1
        }

    def get_rising_crime_communities(self, years):
        """
        Identify communities with rising crime trends over specified years.
        Parameters:
            years (list): A list of years to analyze for crime trends. Must contain at least two years.
        Returns:
            DataFrame with community names and their corresponding percentage change in crime counts between the first and last year, sorted by percentage change in descending order.
        """
        if len(years) < 2:
            print("Not enough years of df to analyze trends.")
            return None

        df = self.df[self.df['Year'].isin(years)]
        group_df = df.groupby(['Community Name', 'Year'])['Crime Count'].sum().reset_index()
        previous_year = min(years)
        current_year = max(years)

        prev_df = group_df[group_df['Year'] == previous_year]
        curr_df = group_df[group_df['Year'] == current_year]

        rising_trends = pd.merge(curr_df, prev_df, on='Community Name', suffixes=('_current', '_previous'))
        rising_trends = rising_trends[rising_trends['Crime Count_previous'] > 0]
        rising_trends['Change'] = ((rising_trends['Crime Count_current'] - rising_trends['Crime Count_previous']) /
                                    rising_trends['Crime Count_previous']) * 100

        return rising_trends[['Community Name', 'Change']].sort_values(by='Change', ascending=False)