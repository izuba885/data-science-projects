import pandas as pd

class DataCleaning:
    """This script is responsible for cleaning the Calgary crime data, handling missing values, and preparing the dataset for analysis and visualization.
    It includes functions to load the raw data, perform necessary transformations, and save the cleaned data for use in other parts of the project.
    The cleaning process involves:
    Removing rows with missing values in critical columns such as 'Crime Count' and 'Community Name'.
    Converting data types for 'Crime Count' and 'Year' to integers for accurate analysis
    Standardizing the 'Community Name' column by stripping extra spaces and converting to uppercase.
    Removing duplicate rows to ensure data integrity.
    Removing rows with negative crime counts, as they are invalid.
    Finally, the cleaned dataset is saved to a new CSV file for use in analysis and visualization.
    """
    def __init__(self, file_path):
        self.file_path = file_path
    def clean_data(self):
        df = pd.read_csv(self.file_path)

        # Remove missing values for records w/o count or location
        df = df.dropna(subset=['Crime Count', 'Community Name'])
        print(f"Rows after dropping missing Crime Count & Community Name: {len(df)}")

        # Crime Count and year count stored as a whole number
        # Already in int64, but still kept as a general validation step
        df['Crime Count'] = df['Crime Count'].astype(int)
        df['Year'] = df['Year'].astype(int)

        # remove extra spaces and make uppercase
        df['Community Name'] = df['Community Name'].str.strip().str.upper()

        # Remove any duplicate rows
        before = len(df)
        df = df.drop_duplicates()
        print(f"Removed {before - len(df)} duplicate rows.")

        # Remove rows where Crime Count is negative
        df = df[df['Crime Count'] >= 0]
        print(f"Rows after removing negative crime counts: {len(df)}")

        # Save cleaned data to CSV
        df.to_csv("../data/Cleaned_Crime_Data.csv", index=False)
        print("Cleaned data saved to Cleaned_Crime_Data.csv")

        return df