import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

class DataVisualization:

    def __init__(self, df, updated_data_path):
        """
        Initialize the visualizer with a cleaned DataFrame.
        Parameters:
            df (pd.DataFrame): The main cleaned crime dataset.
        """
        self.df = df
        self.updated_data_path = updated_data_path

    def plot_crimes_per_year(self):
        """
        Display a bar chart showing total crime counts grouped by year.
        """
        yearly = self.df.groupby('Year')['Crime Count'].sum()
        plt.figure(figsize=(10, 5))
        plt.bar(yearly.index, yearly.values, color='steelblue', edgecolor='black', width=0.8)
        plt.title('Total Crimes Per Year in Calgary')
        plt.xlabel('Year')
        plt.ylabel('Total Crime Count')
        plt.tight_layout()
        plt.savefig("../plots/crimes_per_year.png",dpi=300)
        plt.show()

    def plot_top_communities(self):
        """
        Display a bar chart of the top 10 communities by total crime count.
        """
        community_crimes = (self.df.groupby('Community Name')['Crime Count'].sum()
                            .sort_values(ascending=False).head(10))
        plt.figure(figsize=(12, 6))
        plt.bar(community_crimes.index, community_crimes.values, color='tomato', edgecolor='black', width=0.6)
        plt.title('Top 10 Communities by Total Crime')
        plt.xlabel('Community Name')
        plt.ylabel('Total Crime Count')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        plt.savefig("../plots/top_communities.png",dpi=300)
        plt.show()

    def plot_original_vs_updated_data(self):
        """
        Displays a grouped bar chart comparing crime counts between the original
        dataset and the updated 2024 dataset, broken down by year.

        Loads the updated data from self.updated_data_path and plots the crime counts from old and
        new using NumPy for bar positioning.
        """
        # Original dataset: total crimes per year
        original_crimes_per_year = self.df.groupby('Year')['Crime Count'].sum()

        # Load and clean the updated 2024 dataset
        df_2024 = pd.read_csv(self.updated_data_path)

        # Rename columns to match the original dataset format
        df_2024 = df_2024.rename(columns={
            "Community": "Community Name",
            "Total Crime": "Crime Count"
        })

        # remove rows with missing data and clean up column types
        df_2024 = df_2024.dropna(subset=['Crime Count', 'Community Name'])
        df_2024['Crime Count'] = df_2024['Crime Count'].astype(int)
        df_2024['Year'] = df_2024['Year'].astype(int)
        df_2024['Community Name'] = df_2024['Community Name'].str.strip().str.upper()

        # Total crimes per year from the updated file
        crimes_per_year_2024 = df_2024.groupby('Year')['Crime Count'].sum()

        # Align both datasets on a shared years
        # Combine years from both files so no year gets left out
        all_years = sorted(set(original_crimes_per_year.index) | set(crimes_per_year_2024.index))

        original_crime_counts = original_crimes_per_year.reindex(all_years, fill_value=0)
        crime_counts_2024 = crimes_per_year_2024.reindex(all_years, fill_value=0)

        # Use NumPy to calculate bar positions for side by side layout
        bar_width = 0.35
        x = np.arange(len(all_years))  # Base positions for each year group
        original_bar_positions = x - bar_width / 2   # Shift left for original bars
        bar_positions_2024 = x + bar_width / 2       # Shift right for updated bars

        # Draw the grouped bar chart
        fig, ax = plt.subplots(figsize=(12, 6))
        ax.bar(original_bar_positions, original_crime_counts, bar_width,
               label='Original Data', color='steelblue', edgecolor='black')
        ax.bar(bar_positions_2024, crime_counts_2024, bar_width,
               label='Latest Data', color='darkorange', edgecolor='black')

        ax.set_title('Crime Count Comparison: Original vs Latest Data')
        ax.set_xlabel('Year')
        ax.set_ylabel('Total Crime Count')
        ax.set_xticks(x)
        ax.set_xticklabels(all_years)
        ax.legend()
        plt.tight_layout()
        plt.savefig("../plots/original_vs_updated_data.png",dpi=300)
        plt.show()

    def plot_crime_distribution_by_type(self):
        """
        Display a pie chart showing the distribution of crime by type.
        """
        crime_by_type = self.df.groupby('Category')['Crime Count'].sum()
        plt.figure(figsize=(10, 7))
        plt.pie(crime_by_type.values, labels=crime_by_type.index, autopct='%1.1f%%')
        plt.title("Crime Distribution by Type")
        plt.tight_layout()
        plt.savefig("../plots/crime_distribution_by_type.png", dpi=300)
        plt.show()