import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

from DataCleaning import DataCleaning
from AnalyzeCalgaryCrime import AnalyzeCalgaryCrime
from DataVisualization import DataVisualization

# Settings
FILE_PATH = "../data/Community_Crime_Statistics_20240102.csv"
UPDATED_FILE_PATH = "../data/Community-Crime-2024-2025.csv"
YEAR_RANGE = [2019, 2020, 2021, 2022, 2023]
COMMUNITY_1 = "BELTLINE"
COMMUNITY_2 = "FOREST LAWN"

def main():
    """ This is the main script that operates the loading, cleaning, analysis, and visualization of the Calgary crime data.
    It imports the necessary classes and functions from other modules, executes the data processing steps, and generates insights and visualizations based on the cleaned dataset.
    The main function performs the following steps:
    1. Loads the raw crime data from a specified CSV file.
    2. Initializes the AnalyzeCalgaryCrime class with the loaded data and performs various analyses, such as crime counts by year, type, and location, as well as identifying dangerous and safe communities.
    3. Initializes the Visualizer class with the cleaned data and generates visualizations, including trends over time, dangerous communities, and crime distribution by type.
    4. Prints the results of the analyses and displays the generated charts.
    The script is designed to be modular and easy to understand, allowing for future enhancements and modifications as needed.
    """

    df = DataCleaning(FILE_PATH).clean_data()

    #Analysis
    analyzer = AnalyzeCalgaryCrime(df)

    print("Crimes by Year")
    print(analyzer.crime_by_year())

    print("Crimes by Type")
    print(analyzer.crime_by_type())
     
    print("Crimes by location")
    print(analyzer.crime_by_location())
     
    print("Top 10 most dangerous areas")
    print(analyzer.get_dangerous_areas(10))
     
    print("Top 10 safest communities")
    print(analyzer.get_safest_communities(10))
     
    print("Compare two communities")
    result = analyzer.compare_communities(COMMUNITY_1, COMMUNITY_2)
    if result:
        print(f"{result['Community 1']}: {result['Total Crimes 1']:,} total crimes")
        print(f"{result['Community 2']}: {result['Total Crimes 2']:,} total crimes")
        print(f"Safer community: {result['Safer Community']}")
     
    print("Rising crime communities: 2019 to 2023")
    print(analyzer.get_rising_crime_communities(YEAR_RANGE))

    print(" Statistics summary for Crime Count")
    stats = analyzer.basic_stats()
    print(f"Mean:   {stats['Mean']}")
    print(f"Median: {stats['Median']}")
    print(f"Std:    {stats['Std']}")
    print(f"Min:    {stats['Min']}")
    print(f"Max:    {stats['Max']}")
    print(f"Total:  {stats['Total']:,}")

    print("Crime and Population Correlation")
    print(analyzer.crime_and_population_correlation())

    # Visualizations
    print("Creating visualization")

    visualize_data = DataVisualization(df, UPDATED_FILE_PATH)
    visualize_data.plot_crimes_per_year()
    visualize_data.plot_top_communities()
    visualize_data.plot_original_vs_updated_data()
    visualize_data.plot_crime_distribution_by_type()

if __name__ == "__main__":
    main()